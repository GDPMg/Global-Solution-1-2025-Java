package br.com.energialert.controller;

import br.com.energialert.model.EventoApagao;
import br.com.energialert.service.EnergiaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.Comparator;

@RestController
@RequestMapping("/energia")
public class EnergiaController {

    @Autowired
    private EnergiaService energiaService;

    @GetMapping("/eventos")
    public List<EventoApagao> getEventos() {
        return energiaService.listarEventos();
    }

    @GetMapping("/eventos/tipo/{tipo}")
    public List<EventoApagao> getEventosPorTipo(@PathVariable String tipo) {
        return energiaService.listarEventos().stream()
                .filter(e -> e.getEvento().equalsIgnoreCase(tipo))
                .toList();
    }

    @GetMapping("/eventos/poste/{nome}")
    public List<EventoApagao> getEventosPorPoste(@PathVariable String nome) {
        return energiaService.listarEventos().stream()
                .filter(e -> e.getPoste().equalsIgnoreCase(nome))
                .toList();
    }

    @GetMapping("/eventos/contagem/tipo")
    public Map<String, Long> contarPorTipo() {
        return energiaService.listarEventos().stream()
                .collect(Collectors.groupingBy(EventoApagao::getEvento, Collectors.counting()));
    }

    @GetMapping("/eventos/contagem/poste")
    public Map<String, Long> contarPorPoste() {
        return energiaService.listarEventos().stream()
                .collect(Collectors.groupingBy(EventoApagao::getPoste, Collectors.counting()));
    }

    @GetMapping("/eventos/ultimo")
    public EventoApagao getUltimoEvento() {
        return energiaService.listarEventos().stream()
                .max(Comparator.comparing(EventoApagao::getHorarioComoDataHora))
                .orElse(null);
    }

    @GetMapping("/eventos/com-endereco")
    public List<EventoApagao> getEventosComEndereco() {
        return energiaService.listarEventosComEndereco();
    }

}

