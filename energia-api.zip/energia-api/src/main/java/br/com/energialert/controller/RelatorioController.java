package br.com.energialert.controller;

import br.com.energialert.model.EventoApagao;
import br.com.energialert.service.EnergiaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class RelatorioController {

    @Autowired
    private EnergiaService energiaService;

    @GetMapping("/dashboard")
    public String exibirDashboard(Model model) {
        List<EventoApagao> eventos = energiaService.listarEventos();

        long contagemQueda = eventos.stream()
                .filter(e -> e.getEvento().equalsIgnoreCase("queda"))
                .count();

        long contagemRetorno = eventos.stream()
                .filter(e -> e.getEvento().equalsIgnoreCase("retorno"))
                .count();

        model.addAttribute("eventos", eventos);
        model.addAttribute("contagemQueda", contagemQueda);
        model.addAttribute("contagemRetorno", contagemRetorno);

        return "relatorio";
    }
}