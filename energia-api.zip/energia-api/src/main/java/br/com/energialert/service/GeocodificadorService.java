package br.com.energialert.service;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.core.ParameterizedTypeReference;

import java.util.Map;

@Service
public class GeocodificadorService {

    public String buscarEnderecoPorLatLong(String latlong) {
        try {
            String[] partes = latlong.split(",");
            String lat = partes[0].trim();
            String lon = partes[1].trim();

            String url = "https://nominatim.openstreetmap.org/reverse?lat=" + lat +
                         "&lon=" + lon + "&format=json";

            HttpHeaders headers = new HttpHeaders();
            headers.set("User-Agent", "EnergiAlert");

            HttpEntity<String> entity = new HttpEntity<>(headers);
            RestTemplate restTemplate = new RestTemplate();

            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    new ParameterizedTypeReference<>() {}
            );

            Map<String, Object> body = response.getBody();
            if (body != null && body.containsKey("display_name")) {
                return body.get("display_name").toString();
            }

        } catch (Exception e) {
            System.err.println("Erro ao buscar endereço: " + e.getMessage());
        }

        return "Endereço não encontrado";
    }
}
