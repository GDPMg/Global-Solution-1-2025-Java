package br.com.energialert.exception;

public class ApiException extends RuntimeException {
    public ApiException(String mensagem) {
        super(mensagem);
    }
}