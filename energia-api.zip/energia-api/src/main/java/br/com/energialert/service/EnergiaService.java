package br.com.energialert.service;

import br.com.energialert.client.ApiExternaClient;
import br.com.energialert.model.EventoApagao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnergiaService {

    @Autowired
    private ApiExternaClient apiClient;

    public List<EventoApagao> listarEventos() {
        return apiClient.obterEventos();
    }

    @Autowired
    private GeocodificadorService geocodificadorService;

    public List<EventoApagao> listarEventosComEndereco() {
        List<EventoApagao> eventos = apiClient.obterEventos();

        for (EventoApagao evento : eventos) {
            if (evento.getLocalizacao() != null && evento.getLocalizacao().getLatlong() != null) {
                String endereco = geocodificadorService.buscarEnderecoPorLatLong(evento.getLocalizacao().getLatlong());
                evento.setEnderecoFormatado(endereco);
            }
        }

        return eventos;
    }
}