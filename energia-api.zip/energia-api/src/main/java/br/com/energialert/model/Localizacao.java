package br.com.energialert.model;

public class Localizacao {
    private String latlong;
    private String cidade;
    private String estado;
    private String pais;


    public String getLatlong() { return latlong; }
    public void setLatlong(String latlong) { this.latlong = latlong; }

    public String getCidade() { return cidade; }
    public void setCidade(String cidade) { this.cidade = cidade; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getPais() { return pais; }
    public void setPais(String pais) { this.pais = pais; }
}