package br.com.energialert.client;

import br.com.energialert.exception.ApiException;
import br.com.energialert.model.EventoApagao;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Component
public class ApiExternaClient {

    private final String API_URL = "https://run.mocky.io/v3/ff2d1e0f-fb6c-4b84-bba1-4614b73e64d5";
    private final RestTemplate restTemplate = new RestTemplate();

    public List<EventoApagao> obterEventos() {
        try {
            EventoApagao[] eventos = restTemplate.getForObject(API_URL, EventoApagao[].class);
            return Arrays.asList(eventos);
        } catch (RestClientException e) {
            throw new ApiException("Não foi possível consultar os eventos de apagão. Tente novamente mais tarde.");
        }
    }
}
