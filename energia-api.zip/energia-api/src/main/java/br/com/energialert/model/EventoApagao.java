package br.com.energialert.model;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class EventoApagao {
    private int id;
    private String horario;
    private String evento;
    private String poste;
    private int brilho;
    private Localizacao localizacao;
    private String enderecoFormatado;


    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getHorario() { return horario; }
    public void setHorario(String horario) { this.horario = horario; }

    public String getEvento() { return evento; }
    public void setEvento(String evento) { this.evento = evento; }

    public String getPoste() { return poste; }
    public void setPoste(String poste) { this.poste = poste; }

    public int getBrilho() { return brilho; }
    public void setBrilho(int brilho) { this.brilho = brilho; }

    public Localizacao getLocalizacao() { return localizacao; }
    public void setLocalizacao(Localizacao localizacao) { this.localizacao = localizacao; }

    public LocalDateTime getHorarioComoDataHora() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return LocalDateTime.parse(horario, formatter);
    }

    public String getEnderecoFormatado() {
        return enderecoFormatado;
    }

    public void setEnderecoFormatado(String enderecoFormatado) {
        this.enderecoFormatado = enderecoFormatado;
    }
}